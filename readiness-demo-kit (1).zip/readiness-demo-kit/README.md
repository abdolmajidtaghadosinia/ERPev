# Readiness Demo Kit (سامانه آمادگی)

Hand-off package for building the demo of the emergency-readiness assessment system with Claude Code.

## Start here
1. Put this folder in a new empty repo directory.
2. Open it with Claude Code and say, for example:
   > Read CLAUDE.md and PRD.md fully, then build milestone M0 and stop for my review.
3. Continue milestone by milestone (M0 … M6 in PRD §17).

## Contents
| Path | What |
|---|---|
| `PRD.md` | Full product requirements (Persian prose, English identifiers). Source of truth. |
| `CLAUDE.md` | Rules for Claude Code (read automatically). |
| `data/question-bank.json` | Fixed question bank: 13 indicators, 108 sub-indicators, 809 questions. |
| `data/scoring-test-vectors.json` | Golden vectors for the scoring module. |
| `data/suggested-evidence.json` | Advisory evidence hints for 513 questions. |
| `data/source/question-bank.xlsx` | Original Excel (only for regenerating the JSON). |
| `scripts/` | Python scripts that generate the two JSON files from the Excel. |
| `reference/` | Screenshots of the old demo (visual reference only). |
