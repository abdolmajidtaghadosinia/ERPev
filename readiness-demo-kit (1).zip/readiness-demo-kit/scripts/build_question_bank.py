#!/usr/bin/env python3
"""
Build data/question-bank.json from data/source/question-bank.xlsx.

The Excel file is the single source of truth for: indicators (one per sheet),
sub-indicators (merged cells in column A), questions (rows) and priorities
(column F, values 1..3). Everything else in the workbook (the "answer" column,
the "G" formula/deadline column and the old summary tables in columns J:O)
is intentionally ignored.

Usage:  python3 scripts/build_question_bank.py
Needs:  pip install openpyxl
"""
import json
import re
from collections import OrderedDict
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parent.parent
XLSX = ROOT / "data" / "source" / "question-bank.xlsx"
HINTS = ROOT / "data" / "suggested-evidence.json"
OUT = ROOT / "data" / "question-bank.json"

# Sheet order in the workbook == canonical indicator order (do not reorder).
# Excel sheet titles are truncated (31 chars) so clean names are given here.
INDICATORS = [
    ("IND-01", "برنامه‌ریزی مدیریت شرایط اضطراری", "برنامه‌ریزی"),
    ("IND-02", "آموزش مدیریت شرایط اضطراری", "آموزش"),
    ("IND-03", "تمرین و آزمون", "تمرین و آزمون"),
    ("IND-04", "ارتباطات در مدیریت شرایط اضطراری", "ارتباطات"),
    ("IND-05", "لجستیک پاسخ اضطراری", "لجستیک"),
    ("IND-06", "تجهیزات ایمنی", "تجهیزات ایمنی"),
    ("IND-07", "فرماندهی حادثه", "فرماندهی حادثه"),
    ("IND-08", "ارزیابی خطر در مدیریت شرایط اضطراری", "ارزیابی خطر"),
    ("IND-09", "ارزیابی مستندسازی", "مستندسازی"),
    ("IND-10", "هماهنگی در مدیریت شرایط اضطراری", "هماهنگی"),
    ("IND-11", "پوشش بیمه و تداوم", "بیمه و تداوم"),
    ("IND-12", "تخلیه اضطراری", "تخلیه اضطراری"),
    ("IND-13", "اطلاع‌رسانی و ارتباطات بحران", "ارتباطات بحران"),
]

PRIORITY_LABEL = {3: "بحرانی", 2: "بالا", 1: "متوسط"}
DECISION_POINTS = {"YES": 3, "CORRECTIVE": 1, "NO": 0}


def clean(s):
    return re.sub(r"\s+", " ", str(s)).strip()


def main():
    wb = openpyxl.load_workbook(XLSX, data_only=False)
    assert len(wb.worksheets) == len(INDICATORS), "unexpected number of sheets"
    hints = json.loads(HINTS.read_text(encoding="utf-8")) if HINTS.exists() else {}

    indicators, subs, questions = [], [], []
    for idx, (ws, (ind_id, name, short)) in enumerate(zip(wb.worksheets, INDICATORS), start=1):
        group = None
        sub_by_name = OrderedDict()
        q_order = 0
        letters = set()
        for r in range(2, ws.max_row + 1):
            a, b, c, d, f = (ws.cell(r, k).value for k in (1, 2, 3, 4, 6))
            if a is not None and clean(a):
                group = clean(a)
            if b is None or d is None:
                continue  # blank rows and in-sheet section headers (e.g. "بخش F: ...")
            code = clean(b)
            assert group, f"{ws.title} row {r}: question without sub-indicator"
            prio = int(f)
            assert prio in (1, 2, 3), f"{ws.title} row {r}: bad priority {f!r}"
            if group not in sub_by_name:
                sub_id = f"{ind_id}-S{len(sub_by_name) + 1:02d}"
                sub_by_name[group] = {
                    "id": sub_id, "indicator_id": ind_id, "order": len(sub_by_name) + 1,
                    "name_fa": group, "question_ids": [],
                }
            q_order += 1
            letters.add(re.match(r"[A-Za-z]+", code).group(0))
            sub = sub_by_name[group]
            sub["question_ids"].append(code)
            questions.append({
                "id": code,
                "indicator_id": ind_id,
                "sub_indicator_id": sub["id"],
                "order": q_order,
                "source_code": clean(c) if c is not None else None,
                "text_fa": clean(d),
                "priority": prio,
                "priority_label_fa": PRIORITY_LABEL[prio],
                "max_points": 3 * prio,
                "suggested_evidence_fa": hints.get(code),
            })
        assert len(letters) == 1, f"{ws.title}: mixed id letters {letters}"
        indicators.append({
            "id": ind_id, "order": idx, "id_letter": letters.pop(),
            "name_fa": name, "short_name_fa": short,
            "source_sheet": ws.title,
        })
        subs.extend(sub_by_name.values())

    # ---- derived numbers (weights come ONLY from priorities) --------------
    prio_of = {q["id"]: q["priority"] for q in questions}
    assert len(prio_of) == len(questions), "duplicate question ids"
    total_sum_p = sum(prio_of.values())

    for s in subs:
        s["question_count"] = len(s["question_ids"])
        s["sum_priority"] = sum(prio_of[q] for q in s["question_ids"])
        s["max_points"] = 3 * s["sum_priority"]
    for i in indicators:
        its = [s for s in subs if s["indicator_id"] == i["id"]]
        i["sub_indicator_count"] = len(its)
        i["question_count"] = sum(s["question_count"] for s in its)
        i["sum_priority"] = sum(s["sum_priority"] for s in its)
        i["max_points"] = 3 * i["sum_priority"]
        i["weight_overall"] = i["sum_priority"] / total_sum_p
        for s in its:
            s["weight_in_indicator"] = s["sum_priority"] / i["sum_priority"]
            s["weight_overall"] = s["sum_priority"] / total_sum_p
    for q in questions:
        q["weight_overall"] = q["priority"] / total_sum_p

    meta = {
        "version": "1.0",
        "source_file": "data/source/question-bank.xlsx",
        "note_fa": "بانک سؤال ثابت است. وزن‌ها فقط از اولویت‌ها محاسبه می‌شوند. این فایل را دستی ویرایش نکنید؛ با scripts/build_question_bank.py بسازید.",
        "scoring": {
            "decision_points": DECISION_POINTS,
            "question_points": "decision_points * priority",
            "max_points_formula": "3 * sum(priority)",
            "percent_formula": "sum(points) / sum(max_points) * 100",
        },
        "priority_label_fa": {str(k): v for k, v in PRIORITY_LABEL.items()},
        "totals": {
            "indicators": len(indicators),
            "sub_indicators": len(subs),
            "questions": len(questions),
            "sum_priority": total_sum_p,
            "max_points": 3 * total_sum_p,
            "questions_by_priority": {str(p): sum(1 for q in questions if q["priority"] == p) for p in (3, 2, 1)},
            "questions_with_suggested_evidence": sum(1 for q in questions if q["suggested_evidence_fa"]),
        },
    }
    OUT.write_text(json.dumps({"meta": meta, "indicators": indicators, "sub_indicators": subs, "questions": questions},
                              ensure_ascii=False, indent=1), encoding="utf-8")
    print("wrote", OUT.relative_to(ROOT), meta["totals"])


if __name__ == "__main__":
    main()
