#!/usr/bin/env python3
"""
Build data/scoring-test-vectors.json: golden vectors for the scoring library.

The expectations are computed here with a deliberately naive implementation
(straight from the formulas in PRD.md §6) so that the app's own scoring module
can be tested against an independent oracle.

Usage:  python3 scripts/build_test_vectors.py     (run after build_question_bank.py)
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
bank = json.loads((ROOT / "data" / "question-bank.json").read_text(encoding="utf-8"))
Q = bank["questions"]
POINTS = {"YES": 3, "CORRECTIVE": 1, "NO": 0}
MAX_ALL = bank["meta"]["totals"]["max_points"]


def summarize(decisions):
    """decisions: {question_id: 'YES'|'CORRECTIVE'|'NO'} (may be partial)."""
    by_q = {q["id"]: q for q in Q}
    pts = {qid: POINTS[d] * by_q[qid]["priority"] for qid, d in decisions.items()}
    out = {"overall": {"points": sum(pts.values()), "max_points": MAX_ALL}}
    out["overall"]["percent"] = 100 * out["overall"]["points"] / MAX_ALL
    ind, sub = {}, {}
    for i in bank["indicators"]:
        p = sum(v for k, v in pts.items() if by_q[k]["indicator_id"] == i["id"])
        ind[i["id"]] = {"points": p, "max_points": i["max_points"], "percent": 100 * p / i["max_points"]}
    for s in bank["sub_indicators"]:
        p = sum(v for k, v in pts.items() if by_q[k]["sub_indicator_id"] == s["id"])
        sub[s["id"]] = {"points": p, "max_points": s["max_points"], "percent": 100 * p / s["max_points"]}
    out["indicators"], out["sub_indicators"] = ind, sub
    return out


def vec(name, desc, rule, decisions, note=None):
    v = {"name": name, "description_fa": desc, "rule": rule, "expected": summarize(decisions)}
    if note:
        v["note"] = note
    return v


vectors = []
vectors.append(vec("ALL_YES", "همه‌ی سؤال‌ها «بله»", {"default": "YES"}, {q["id"]: "YES" for q in Q}))
vectors.append(vec("ALL_CORRECTIVE", "همه‌ی سؤال‌ها «اقدام اصلاحی»", {"default": "CORRECTIVE"}, {q["id"]: "CORRECTIVE" for q in Q}))
vectors.append(vec("ALL_NO", "همه‌ی سؤال‌ها «خیر»", {"default": "NO"}, {q["id"]: "NO" for q in Q}))
vectors.append(vec(
    "CRITICAL_NO_REST_YES", "همه‌ی سؤال‌های بحرانی (priority=3) «خیر» و بقیه «بله»",
    {"priority_3": "NO", "otherwise": "YES"},
    {q["id"]: ("NO" if q["priority"] == 3 else "YES") for q in Q},
    "نشان می‌دهد وزن ۳:۲:۱ سد ایمنی نیست؛ امتیاز کل حدود ۷۶٫۵٪ می‌ماند."))
vectors.append(vec(
    "ONLY_CRITICAL_YES", "فقط سؤال‌های بحرانی «بله» و بقیه «خیر»",
    {"priority_3": "YES", "otherwise": "NO"},
    {q["id"]: ("YES" if q["priority"] == 3 else "NO") for q in Q}))
cyc = ["YES", "CORRECTIVE", "NO"]
vectors.append(vec(
    "CYCLE_BY_ORDER", "در هر شاخص، سؤال‌ها به ترتیب (order) به‌صورت چرخشی YES, CORRECTIVE, NO می‌گیرند (order=1 → YES)",
    {"decision": "cycle[(order-1) % 3] with cycle=[YES,CORRECTIVE,NO]"},
    {q["id"]: cyc[(q["order"] - 1) % 3] for q in Q}))

# Partial scoring: only the first 100 questions (global bank order) are scored.
first100 = {q["id"]: "YES" for q in Q[:100]}
pv = vec("PARTIAL_FIRST_100_YES", "فقط ۱۰۰ سؤال اول بانک «بله» خورده‌اند و بقیه هنوز نمره‌ی ارزیاب ندارند",
         {"first_n": 100, "decision": "YES", "others": "unscored"}, first100,
         "پیش‌نمایش درصد همیشه نسبت به کل حداکثر (۴۵۲۴) است، نه فقط سؤال‌های نمره‌خورده. unscored_count باید ۷۰۹ باشد.")
pv["expected"]["unscored_count"] = len(Q) - 100
vectors.append(pv)

# Hand-checkable examples
a1 = [q for q in Q if q["sub_indicator_id"] == "IND-01-S01"]
assert [q["priority"] for q in a1] == [3] * 6
hand = {a1[0]["id"]: "YES", a1[1]["id"]: "YES", a1[2]["id"]: "YES",
        a1[3]["id"]: "CORRECTIVE", a1[4]["id"]: "NO", a1[5]["id"]: "YES"}
hv = vec("HAND_PLANNING_S01", "مثال دست‌محاسبه: زیرشاخص «سیاست، ساختار و فرماندهی» (۶ سؤال همه priority=3)",
         {"explicit": hand}, hand,
         "9+9+9+3+0+9 = 39 از 54 → 72.2٪")
vectors.append(hv)

# Single-question example from the product owner: critical + YES = 9
vectors.append({"name": "SINGLE_QUESTION_EXAMPLES",
                "description_fa": "امتیاز یک سؤال = تصمیم ارزیاب × اولویت",
                "table": [
                    {"decision": d, "priority": p, "points": POINTS[d] * p}
                    for p in (3, 2, 1) for d in ("YES", "CORRECTIVE", "NO")]})

(ROOT / "data" / "scoring-test-vectors.json").write_text(
    json.dumps({"meta": {"max_points": MAX_ALL, "tolerance": 1e-9}, "vectors": vectors}, ensure_ascii=False, indent=1),
    encoding="utf-8")
for v in vectors:
    if "expected" in v:
        e = v["expected"]["overall"]
        print(f'{v["name"]:26} points={e["points"]:5} percent={e["percent"]:.4f}')
